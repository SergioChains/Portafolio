#!/bin/bash
# Esto es un comentario
echo "Hola mundo"

