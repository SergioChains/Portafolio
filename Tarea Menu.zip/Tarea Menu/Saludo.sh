#!/bin/bash
# En la primera linea establezco con qué shell se debe ejecutar
# Se define una variable
SALUDO="Hola mundo"
echo -n "Este script te dice: "
echo ${SALUDO}

